// Initialize Firebase
var config = {
    apiKey: "AIzaSyAgFSXyfrZ8Di_V_9ors0VgedYqnurb9u0",
    authDomain: "socialratingsapp.firebaseapp.com",
    databaseURL: "https://socialratingsapp.firebaseio.com",
    projectId: "socialratingsapp",
    storageBucket: "socialratingsapp.appspot.com",
    messagingSenderId: "8228083925"
};
firebase.initializeApp(config);

var databaseUserSnapshot;
var nearbyUserDistanceThreshold = 0.1;
var locationWatch;
var locationWatchOptions;

$(document).ready(function () {

    // Called on the client when the state of any user is changed (e.g if they log in or log out).
    // If firebaseUser is null, this means no user is signed in.
    firebase.auth().onAuthStateChanged(firebaseUser => {
        if(firebaseUser)
        {
            // If we have a user logged in, store their UID and show the Feed page.
            sessionStorage.setItem('userUID', firebaseUser.uid);
            $.mobile.changePage('#feed-page', {transition : "pop", reverse : true});
            LoadOrCreate(firebaseUser);

            // Update the snapshot of the database user
            getDatabaseUserSnap();

            // Update the welcome message
            firebase.database().ref("users/" + sessionStorage.getItem('userUID')).once('value').then(function (snapshot) {
                $('#welcome-message').html("<b>Welcome,</b> " + snapshot.val().firstName + " " + snapshot.val().lastName + "!");
                console.log("User Logged In " + snapshot.val().email)
            });

            // Initialize the location fetch for the user
            getLocation();
        }
        else
        {
            // No user is logged in, return to the initial index page
            $.mobile.changePage('#index-page', {transition: "pop", reverse: true});
            console.log("User Logged Out");
        }
    });
});

// Check if we currently have the logged in user registers in the real-time database. If not, we create them.
function LoadOrCreate(firebaseUser)
{
    var accountFound = false;
    firebase.database().ref("users").once("value").then(function (snapshot) {
        snapshot.forEach(function (child) {
            var newItemValue = child.val();

            if(newItemValue.uid === firebaseUser.uid)
                accountFound = true;
        });


        if(!accountFound)
        {
            firebase.database().ref("users/" + sessionStorage.getItem('userUID')).set({
                email: firebaseUser.email,
                firstName: sessionStorage.getItem('firstName'),
                lastName: sessionStorage.getItem('lastName'),
                uid: firebaseUser.uid
            });
        }
    });
}

// Logs in the user with the given email & password
function userLogin(email, password) {
    const auth = firebase.auth();
    var promise = auth.signInWithEmailAndPassword(email, password);
    promise.catch(e => console.log(e.message));
}

// Attempts to create a new user account with the given details
function userSignup(email, password, confirmPassword, firstName, lastName) {

    if(password !== confirmPassword )
    {
        console.log("Passwords do not match");
        return;
    }

    if(!email.toString().includes('@') || email === "")
    {
        console.log("Email is bad format");
        return;
    }

    if(firstName === "")
    {
        console.log("First name required");
        return;
    }

    if(lastName === "")
    {
        console.log("Last name required");
        return;
    }

    const auth = firebase.auth();
    var promise = auth.createUserWithEmailAndPassword(email, password);

    // Store the first and last name in session storage.
    sessionStorage.setItem('firstName', firstName);
    sessionStorage.setItem('lastName', lastName);

    promise.catch(e => console.log(e.message));
}

// Logs out the current user accounts
function userLogout()
{
    firebase.auth().signOut();
}

// Attempts to gain a snap shot of the current logged in user account from the real-time database.
function getDatabaseUserSnap()
{
    firebase.database().ref("users/" + sessionStorage.getItem('userUID')).once('value').then(function (snapshot) {
        databaseUserSnapshot = snapshot.val();
    });
}

function DEBUG_SendLocation(lat, lon)
{
    firebase.database().ref("locations/" + sessionStorage.getItem('userUID')).set({
        latitude: lat,
        longitude: lon,
        uid: sessionStorage.getItem('userUID')
    });
    findNearby(lat, lon);
}

// Initializes the location fetching for the user.
function getLocation()
{
    if(navigator.geolocation)
    {
        // navigator.geolocation.getCurrentPosition(function (position) {
        //     firebase.database().ref("locations/" + sessionStorage.getItem('userUID')).set({
        //         latitude: position.coords.latitude,
        //         longitude: position.coords.longitude,
        //         uid: sessionStorage.getItem('userUID')
        //     });
        //     findNearby(position.coords.latitude, position.coords.longitude);
        // });

        locationWatchOptions = {
            enableHighAccuracy: true,
            timeout: 5000,
            maximumAge: 0
        };

        // Listen for the user to change position, and when they do, update the real-time database
        id = navigator.geolocation.watchPosition(watchPositionSucess, watchPositionError, locationWatchOptions);
    }
}

// When called, this updates the users location
function watchPositionSucess(position) {
    firebase.database().ref("locations/" + sessionStorage.getItem('userUID')).set({
        latitude: position.coords.latitude,
        longitude: position.coords.longitude,
        uid: sessionStorage.getItem('userUID')
    });
    findNearby(position.coords.latitude, position.coords.longitude);
    initMap(position.coords.latitude, position.coords.longitude);
    console.log(position.coords.latitude, position.coords.longitude);
    console.log("Position Watch Returned");
}

function watchPositionError(err) {
    console.warn('ERROR(' + err.code + '): ' + err.message);
}

// Finds all users accounts within a distance threshold to the given lat & lon
function findNearby(lat, lon)
{
    var nearby = [];
    firebase.database().ref("locations").once("value").then(function (snapshot) {
        snapshot.forEach(function (child) {
            var newItemValue = child.val();

            var dist = calculateDistance(newItemValue.latitude, newItemValue.longitude, lat, lon)
            if(dist<= nearbyUserDistanceThreshold)
            {
                if(newItemValue.uid !== sessionStorage.getItem('userUID'))
                    nearby.push(newItemValue);
            }
        });

        console.log(nearby.length + " Users Nearby");
        for (var i = 0, len = nearby.length; i < len; i++) {
            console.log(calculateDistance(nearby[i].latitude, nearby[i].longitude, lat, lon) + " distance away");
        }
    });
}

// Calculates the distance between two coordinate points.
function calculateDistance(lat1, lon1, lat2, lon2)
{
    //Radius of the earth in:  1.609344 miles,  6371 km  | var R = (6371 / 1.609344);
    var R = 3958.7558657440545; // Radius of earth in Miles
    var dLat = toRad(lat2-lat1);
    var dLon = toRad(lon2-lon1);
    var a = Math.sin(dLat/2) * Math.sin(dLat/2) +
        Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) *
        Math.sin(dLon/2) * Math.sin(dLon/2);
    var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    var d = R * c;
    return d;
}

// Converts degress to radians
function toRad(Value)
{
    return Value * Math.PI / 180;
}

function initMap(lat, lon) {
    var position = {lat: lat, lng: lon};
    var map = new google.maps.Map(document.getElementById('map'), {
        zoom: 16,
        center: position
    });
    var marker = new google.maps.Marker({
        position: position,
        map: map
    });
}